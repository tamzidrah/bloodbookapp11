(function(_w, _d) {
    var BB = BB || {};
    var elm = Element;
    BB.ready = function(callback) {
        if (_d.addEventListener) {
            _d.addEventListener("DOMContentLoaded", callback, false);
        } else if (_d.attachEvent) {
            _d.attachEvent("onreadystatechange", function() {
                if (_d.readyState === "complete") {
                    callback();
                }
            });
        } else {
            var oldOnload = window.onload;
            window.onload = function() {
                oldOnload && oldOnload();
                callback();
            };
        }
    };
    BB.gid = function(id) {
        return _d.getElementById(id);
    };
    BB.qs = function(selector, node = null) {
        if (node === null && this instanceof Element) {
            node = this;
        }
        return node ? node.querySelector(selector) : _d.querySelector(selector);
    };
    BB.qsa = function(selector, node = null) {
        if (node === null && this instanceof Element) {
            node = this;
        }
        return node ? node.querySelectorAll(selector) : _d.querySelectorAll(selector);
    };
    BB.attr = function(attr, node = null) {
        if (node === null && this instanceof Element) {
            node = this;
        }
        return node ? node.getAttribute(attr) : "";
    };
    BB.addEv = function(type, listener = function() {}, options = null) {
        if (options === null) {
            this.addEventListener(type, listener);
        } else {
            this.addEventListener(type, listener, options);
        }
    };
    BB.delEv = function(type, listener = function() {}, options = null) {
        if (options === null) {
            this.removeEventListener(type, listener);
        } else {
            this.removeEventListener(type, listener, options);
        }
    };
    BB.fireEv = function(element, event) {
        var evt;
        if (_d.createEventObject) {
            evt = _d.createEventObject();
            return element.fireEvent("on" + event, evt);
        } else if ("createEvent" in _d) {
            evt = _d.createEvent("HTMLEvents");
            evt.initEvent(event, true, true);
            return !element.dispatchEvent(evt);
        } else if (_d.all && !_d.addEventListener) {
            return element.dispatchEvent(new CustomEvent(event));
        }
        return false;
    };
    BB.html = function(content = "", node = null, append = false) {
        if (node instanceof Element) {
            node.innerHTML = content;
            return node.innerHTML;
        } else if (append) {
            this.innerHTML += content;
            return this.innerHTML;
        }
        this.innerHTML = content;
        return this.innerHTML;
    };
    BB.insertHTML = function(content = "", node = null, position = "afterend") {
        if (node instanceof Element) {
            node.insertAdjacentHTML(position, content);
            return node.innerHTML;
        }
        this.insertAdjacentHTML(position, content);
        return this.innerHTML;
    };
    BB.text = function(content = "", node = null, append = false) {
        if (node instanceof Element) {
            node.innerText = content;
            return node.innerText;
        } else if (append) {
            this.innerText += content;
            return this.innerText;
        }
        this.innerText = content;
        return this.innerText;
    };
    BB.lowercase = function() {
        return this.toLowerCase();
    };
    BB.uppercase = function() {
        return this.toUpperCase();
    };
    BB.str = function() {
        return this.toString();
    };
    BB.chr = function(code) {
        return String.fromCharCode(code);
    };
    BB.ord = function(str) {
        return str.charCodeAt(0);
    };
    BB.strrev = function(s) {
        return [...s].reverse().join("");
    };
    BB.rtrim = function(char) {
        if (char === undefined) {
            char = "s";
        }
        const regExp = new RegExp(`${char}+$`);
        return this.replace(regExp, "");
    };
    BB.ltrim = function(char) {
        if (char === undefined) {
            char = "s";
        }
        const regExp = new RegExp(`${char}+$`);
        return this.replace(new RegExp("^[" + char + "]+"), "");
    };
    BB.clog = function(params) {
        console.log(params);
    };
    BB.findXPath = function(xpath) {
        let matchingElement = _d.evaluate(xpath, _d, null, XPathResult.ANY_TYPE, null);
        return matchingElement.iterateNext();
    };
    BB.isNumeric = function(v) {
        return /^\d+$/.test(v);
    };
    BB.cursor_wait = function() {
        _d.body.style.cursor = "wait";
    };
    BB.cursor_default = function() {
        _d.body.style.cursor = "default";
    };
    BB.ls_get = function(key) {
        return localStorage.getItem(key);
    };
    BB.ls_set = function(key, value) {
        localStorage.setItem(key, value);
    };
    BB.ls_has = function(key) {
        return !(localStorage.getItem(key) == null);
    };
    BB.bh_cui = function() {
        const meta_csrf_token = _.qs('meta[name="csrf_token"]');
        const meta_user_id = _.qs('meta[name="user_id"]');
        let csrf_token = "",
            user_id = "";
        if (meta_csrf_token) {
            csrf_token = meta_csrf_token.attr("content");
        }
        if (meta_user_id) {
            user_id = meta_user_id.attr("content");
        }
        return {
            "X-CSRF-Token": csrf_token,
            "X-USER-ID": user_id,
        };
    };
    BB.show_msg = function(message, timeout) {
        if (typeof message == "undefined") message = "";
        if (typeof timeout == "undefined") timeout = 2000;
        showMessage.show(message, false, timeout);
    };
    BB.hide_msg = function(timeout = 2000) {
        setTimeout(function() {
            _w.showMessage.hide();
        }, timeout);
    };
    BB.show_loader = function(selector = null) {
        let mask_loader = _.qs(".mask-loader"),
            loading_bg = _.qs(".loading-bg");
        mask_loader && (mask_loader.style.display = "block");
        loading_bg && (loading_bg.style.display = "block");
    };
    BB.show_inline_loader = function(selector = null) {
        let loading_spinner = _.qs(".loading-spinner");
        if (selector) {
            loading_spinner = _.qs(selector);
        }
        loading_spinner && (loading_spinner.style.display = "inline-block");
    };
    BB.hide_loader = function(selector = null) {
        let mask_loader = _.qs(".mask-loader"),
            loading_bg = _.qs(".loading-bg");
        mask_loader && (mask_loader.style.display = "none");
        loading_bg && (loading_bg.style.display = "none");
    };
    BB.hide_inline_loader = function(selector = null) {
        let loading_spinner = _.qs(".loading-spinner");
        if (selector) {
            loading_spinner = _.qs(selector);
        }
        loading_spinner && (loading_spinner.style.display = "none");
    };
    BB.hb_point_mnt = function(hb_point) {
        if (!hb_point) return;
        hb_point.addEv("keyup", function() {
            let point = this.value,
                point_arr = point.split(".", 2);
            if (point_arr[1] && point_arr[1].length > 2) {
                this.value = point_arr[0].str() + "." + point_arr[1].substring(0, 2);
            }
            if (point_arr[0] && point_arr[0] > 17) {
                this.value = "18.0";
            }
        });
    };
    BB.number_format = function(number) {
        if (!number) return false;
        number = number.replace(/\D/g, "");
        number = number.ltrim("88");
        if (number.length < 10) return false;
        if (number.length == 10 && number.indexOf("1", 0) > -1) {
            number = "0" + number;
        }
        if (number.length != 11 || number.indexOf("01", 0) === -1) {
            return false;
        } else if (!/^01[3-9]\d{8}$/.test(number)) {
            return false;
        }
        return number;
    };
    BB.fb_url_format = function(fb_url) {
        if (fb_url.indexOf("https://") === -1 && fb_url.indexOf("http://") === -1) {
            if (fb_url.indexOf("fb.") === -1 && fb_url.indexOf("m.me/") === -1 && fb_url.indexOf("facebook.") === -1) {
                fb_url = "fb.com/" + fb_url;
            }
            fb_url = "https://" + fb_url;
        }
        const fb_pattern = /^(?:https?:\/\/)?(?:www\.|web\.|mobile\.)?(?:facebook|fb|m\.facebook|m)\.(?:com|me)\/(?:groups\/\d{15}\/user\/|profile\.php\?id\=|)(\d{15}|[\w\.]{5,30}).*$/i;
        if ((match = fb_url.match(fb_pattern))) {
            return match[1];
        }
        return false;
    };
    BB.telegram_format = function(tel_val) {
        const pattern = /(https?:\/\/)?t\.me\//i;
        tel_val = tel_val.replace(pattern, "");
        tel_val = tel_val.replaceAll(/[^\w]/g, "");
        if (_.is_int(tel_val)) {
            return _.number_format(tel_val);
        }
        if (/^\w{5,32}$/g.test(tel_val)) {
            return tel_val;
        }
        return false;
    };
    BB.mark_error = function(selector) {
        let elm = _.qs(selector);
        if (!elm) return false;
        elm.style.color = "red";
        elm.style.borderBottom = "2px solid red";
    };
    BB.mark_okay = function(selector) {
        let elm = _.qs(selector);
        if (!elm) return false;
        elm.style.color = "fieldtext";
        elm.style.borderBottom = "1px solid #111";
    };
    BB.form_validate = function(dataObj) {
        let stop_iter = false,
            number;
        for (let index in dataObj) {
            const value = dataObj[index].trim();
            if (stop_iter) break;
            switch (index) {
                case "blood_group":
                    if (!value || value == "রোগীর রক্তের গ্রুপ") {
                        showMessage.show("একটি রক্তের গ্রুপ নির্বাচন করুন।");
                        stop_iter = true;
                        this.mark_error(`._${index}`);
                    } else {
                        this.mark_okay(`._${index}`);
                    }
                    break;
                case "hb_point":
                    if (value && (value < 6 || value > 18)) {
                        showMessage.show("সঠিক হিমোগ্লোবিন পয়েন্ট লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                case "bb_unit":
                    if (!value) {
                        showMessage.show("রক্তের ব্যাগের পরিমাণ লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else if (value > 10 || value < 1) {
                        showMessage.show("রক্তের ব্যাগের পরিমাণ ১ থেকে ১০ এর মধ্যে হতে হবে।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                case "patient_cond":
                    if (value && value.length > 64) {
                        showMessage.show("সর্বোচ্চ ৬৪টি অক্ষর ব্যবহার করে সমস্যা লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                case "district":
                    if (!value || value == "জেলা") {
                        showMessage.show("আপনার জেলা নির্বাচন করুন।");
                        stop_iter = true;
                        this.mark_error(`._${index}`);
                    } else {
                        this.mark_okay(`._${index}`);
                    }
                    break;
                case "hospital_name":
                    if (!value) {
                        showMessage.show("হাসপাতালের নাম লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else if (value.length > 100) {
                        showMessage.show("সর্বোচ্চ ১০০টি অক্ষর ব্যবহার করে হাসপাতালের নাম লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else if (!/^[.\(\)&"':;a-zA-Z0-9\s\-\u0980-\u09FF]{3,100}$/.test(value)) {
                        showMessage.show("হাসপাতালের সঠিক নাম লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                case "number":
                    number = _.number_format(value);
                    if (value && !number) {
                        showMessage.show("সঠিক মোবাইল নাম্বার লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    dataObj[index] = number;
                    break;
                case "number_opt":
                    number = _.number_format(value);
                    if (value && !number) {
                        showMessage.show("সঠিক মোবাইল নাম্বার লিখুন (ঐচ্ছিক)।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    dataObj[index] = number;
                    break;
                case "telegram":
                    let tel_val = _.telegram_format(value);
                    if (value && !tel_val) {
                        showMessage.show("সঠিক টেলিগ্রাম ইউজার নেইম/নাম্বার লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    dataObj[index] = tel_val;
                    break;
                case "whatsapp":
                    number = _.number_format(value);
                    if (value && !number) {
                        showMessage.show("সঠিক হোয়াটস্যাপ নাম্বার লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    dataObj[index] = number;
                    break;
                case "facebook":
                    let fb_url = _.fb_url_format(value);
                    if (value && !fb_url) {
                        showMessage.show("সঠিক ফেইজবুক প্রোফাইল লিংক লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    dataObj[index] = fb_url;
                    break;
                case "patient_gender":
                    if (!value || value == "রোগীর জেন্ডার") {
                        showMessage.show("রোগীর জেন্ডার নির্বাচন করুন।");
                        stop_iter = true;
                        this.mark_error(`._${index}`);
                    } else {
                        this.mark_okay(`._${index}`);
                    }
                    break;
                case "rel_patient":
                    if (!value || value == "রোগীর সাথে সম্পর্ক") {
                        showMessage.show("রোগীর সাথে সম্পর্ক নির্বাচন করুন।");
                        stop_iter = true;
                        this.mark_error(`._${index}`);
                    } else {
                        this.mark_okay(`._${index}`);
                    }
                    break;
                case "date_time":
                    let emergency = dataObj.emergency;
                    if (!emergency && !value) {
                        showMessage.show("অনুগ্রহ করে রক্ত দানের তারিখ ও সময় লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                        break;
                    } else if (emergency == "on") {
                        dataObj[index] = "";
                        this.mark_okay(`#${index}`);
                        break;
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    let dt_now = new Date().getTime(),
                        slc_dt = new Date(value).getTime();
                    if (dt_now + 1800 >= slc_dt) {
                        showMessage.show("কমপক্ষে 30 মিনিট পরের সময় নির্বাচন করুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                case "details":
                    if (value && value.length > 1024) {
                        showMessage.show("সর্বোচ্চ ১০২৪টি অক্ষর ব্যবহার করে সংক্ষিপ্ত বিবরণ লিখুন।");
                        stop_iter = true;
                        this.mark_error(`#${index}`);
                    } else {
                        this.mark_okay(`#${index}`);
                    }
                    break;
                default:
                    break;
            }
        }
        return stop_iter == true ? !1 : dataObj;
    };
    BB.valid_any = function() {
        let number = _.gid("number"),
            telegram = _.gid("telegram"),
            whatsapp = _.gid("whatsapp"),
            facebook = _.gid("facebook");
        if (_.number_format(number.value)) {
            return "num";
        } else if (_.telegram_format(telegram.value)) {
            return "tel";
        } else if (_.number_format(whatsapp.value)) {
            return "wa";
        } else if (_.fb_url_format(facebook.value)) {
            return "fb";
        }
        return false;
    };
    BB.contact_handle = function() {
        let number = _.gid("number"),
            telegram = _.gid("telegram"),
            whatsapp = _.gid("whatsapp"),
            facebook = _.gid("facebook"),
            optional_btn = _.qs(".optional_button");
        optional_btn.addEv("click", () => {
            let num_pn = number.parentNode,
                _c = num_pn.cloneNode(true);
            setTimeout((_c.children[0].value = ""));
            _c.children[0].name = "number_opt";
            _c.children[0].id = "number_opt";
            if (_c.children[2]) {
                _c.children[2].remove();
            }
            _c.children[1].innerText = "ঐচ্ছিক";
            _c.children[1].classList.remove("optional_button");
            num_pn ? .insertAdjacentElement("afterend", _c);
            optional_btn.remove();
            setTimeout(opt_num);
        });
        let add_node = function(node) {
                if (has_node(node)) return;
                let prn_node = node.parentNode,
                    _node = _d.createElement("span");
                _node.innerText = "ঐচ্ছিক";
                _node.className = "optional_text";
                prn_node.insertAdjacentElement("beforeend", _node);
            },
            del_node = function(node) {
                let _node = has_node(node);
                _node && _node.remove();
            },
            has_node = function(node) {
                let prn_node = node.parentNode,
                    _node = prn_node.qs(".optional_text:not(.optional_button)");
                return _node ? _node : !1;
            },
            add_nodes = function(exclude = "num") {
                let vnm = _.number_format(number.value);
                if (exclude != "num" && !vnm) {
                    add_node(number);
                } else if (vnm) {
                    del_node(number);
                }
                if (exclude != "tel") {
                    add_node(telegram);
                }
                if (exclude != "wa") {
                    add_node(whatsapp);
                }
                if (exclude != "fb") {
                    add_node(facebook);
                }
            },
            del_nodes = function(exclude = "num") {
                let vnm = _.number_format(number.value),
                    vtl = _.telegram_format(telegram.value),
                    vwa = _.number_format(whatsapp.value),
                    vfb = _.fb_url_format(facebook.value);
                if (exclude != "num" && !vnm) {
                    del_node(number);
                }
                if (exclude != "tel" || !vtl) {
                    del_node(telegram);
                }
                if (exclude != "wa" || !vwa) {
                    del_node(whatsapp);
                }
                if (exclude != "fb" || !vfb) {
                    del_node(facebook);
                }
            },
            opt_num = function() {
                let numb_opt = _.gid("number_opt");
                numb_opt.addEv("change", function() {
                    let opt_val = numb_opt.value;
                    if (opt_val && !_.number_format(opt_val)) {
                        showMessage.show("সঠিক মোবাইল নাম্বার লিখুন (ঐচ্ছিক)।");
                        return !1;
                    }
                    return !0;
                });
            };
        number.addEv("change", () => {
            if (_.number_format(number.value)) {
                add_nodes();
            } else if (!_.valid_any()) {
                del_nodes();
            } else {
                add_node(number);
            }
        });
        telegram.addEv("change", () => {
            if (_.telegram_format(telegram.value)) {
                add_nodes("tel");
            } else if (!_.valid_any()) {
                del_nodes("tel");
            }
        });
        whatsapp.addEv("change", () => {
            if (_.number_format(whatsapp.value)) {
                add_nodes("wa");
            } else if (!_.valid_any()) {
                del_nodes("wa");
            }
        });
        facebook.addEv("change", () => {
            if (_.fb_url_format(facebook.value)) {
                add_nodes("fb");
            } else if (!_.valid_any()) {
                del_nodes("fb");
            }
        });
    };
    BB.new_apl = function() {
        let hb_point = _.gid("hb_point"),
            emergency = _.gid("emergency"),
            date_time = _.gid("date_time"),
            apl_btn = _.gid("apl_btn"),
            form = _.gid("app_form"),
            progress_btn = function() {
                apl_btn.disabled = true;
                apl_btn.style.cursor = "not-allowed";
            },
            normal_btn = function() {
                apl_btn.disabled = false;
                apl_btn.style.cursor = "pointer";
            };
        _.contact_handle();
        _.hb_point_mnt(hb_point);
        emergency.addEv("change", () => {
            if (emergency.checked) {
                date_time.required = false;
            } else {
                date_time.required = true;
            }
        });
        apl_btn.addEv("click", function() {
            progress_btn();
            let formData = new FormData(form),
                dataObj = {};
            for (const [key, value] of formData) {
                dataObj[key] = value;
            }
            let validData = _.form_validate(dataObj),
                ct_valid_any = _.valid_any();
            if (!validData) {
                normal_btn();
                return;
            } else if (!ct_valid_any) {
                showMessage.show("আপনাকে কমপক্ষে একটি যোগাযোগের তথ্য প্রদান করতে হবে।");
                normal_btn();
                return;
            }
            validData.emergency = validData.emergency ? ? "";
            validData.facebook = validData.facebook == false ? "" : validData.facebook;
            validData.number = !validData.number || validData.number == false ? "" : validData.number;
            validData.number_opt = !validData.number_opt || validData.number_opt == false ? "" : validData.number_opt;
            validData.whatsapp = validData.whatsapp == false ? "" : validData.whatsapp;
            validData.telegram = validData.telegram == false ? "" : validData.telegram;
            validData.rqn = new Date().getTime();
            for (let index in validData) {
                let value = validData[index];
                validData[index] = encodeURIComponent(value);
            }
            _.cursor_wait();
            _.show_inline_loader();
            client.post({
                url: "/api/submit-form",
                data: validData,
                headers: _.bh_cui(),
                success: function(data, status, XHR) {
                    try {
                        let jsonData = JSON.parse(data);
                        if (!jsonData) {
                            showMessage.show("Unknown data returned.");
                            return;
                        } else if (jsonData.status == "error") {
                            showMessage.show(jsonData.message);
                            return;
                        }
                        let page_link = jsonData.page_link,
                            state = {
                                name: "home",
                                page: "/"
                            };
                        _.repl_state(state, _w.title, "/");
                        _w.location.href = page_link;
                    } catch (error) {}
                },
                error: function(XHR, status, message) {
                    _.app_mode(status, XHR);
                    showMessage.show(message);
                },
                complete: function(XHR, message) {
                    _.hide_inline_loader();
                    _.cursor_default();
                    normal_btn();
                },
            });
        });
        let data = BB_glo_data,
            u_city = data.ip_city,
            page = data.page;
        if (page == "form") {
            if (_.ls_has("u_city")) {
                u_city = _.ls_get("u_city");
            }
            let xpath = "//option[contains(text(), '" + u_city + "')]",
                ele_match = _.findXPath(xpath),
                district = _.gid("district"),
                districts = _.qsa(".district ._option"),
                bld_groups = _.qsa(".blood_group ._option");
            ele_match && _w.dropdown.update(district, ele_match);
        }
    };
    BB.change_state = function(state, title, url) {
        if (typeof state == "undefined") state = {};
        if (typeof title == "undefined") title = "";
        if (typeof url == "undefined") url = "";
        if (_w.history && _w.history.pushState) {
            _w.history.pushState(state, title, url);
            return true;
        }
        _w.location.href = url;
        return false;
    };
    BB.repl_state = function(state, title, url) {
        if (typeof state == "undefined") state = {};
        if (typeof title == "undefined") title = "";
        if (typeof url == "undefined") url = "";
        if (_w.history && _w.history.replaceState) {
            _w.history.replaceState(state, title, url);
            return true;
        }
        _w.location.replace(url);
        return false;
    };
    BB.pop_state = function() {
        if (history.state && history.state.page) {
            if (history.state.name == "home") {}
        } else {}
    };
    BB.is_int = function(val) {
        return /^\d+$/.test(val);
    };
    BB.report_btn_handler = function(page = "home") {
        let _rep_btn_list = _.qsa("a .report_button");
        _rep_btn_list.forEach((elm) => {
            elm.addEv("click", (ev) => {
                ev.preventDefault();
                let apl_id = elm.attr("data-ai");
                client.post({
                    url: "/api/report",
                    data: {
                        apl_id: apl_id,
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        try {
                            let jsonData = JSON.parse(data);
                            if (!jsonData || jsonData.status == "error") return;
                            if (jsonData.reload) {
                                if (page == "home") {
                                    _.fetch_apl();
                                } else if (page == "my-apps") {
                                    _.fetch_my_apl();
                                }
                            }
                        } catch (error) {}
                    },
                });
            });
        });
    };
    BB.pagination_bh = function() {
        let home_pgn = _.qs(".hm-pgn"),
            my_pgn = _.qs(".my-pgn"),
            pgn_btn;
        if (home_pgn) {
            pgn_btn = _.qsa(".hm-pgn li");
            pgn_btn.forEach((elm) => {
                if (elm.attr("class") == "active") {
                    return;
                } else if (elm.attr("class") == "dotted") {
                    return;
                }
                elm.addEv("click", () => {
                    let offset = elm.attr("data-offset");
                    _.fetch_apl(offset);
                });
            });
        } else if (my_pgn) {
            pgn_btn = _.qsa(".my-pgn li");
            pgn_btn.forEach((elm) => {
                if (elm.attr("class") == "active") {
                    return;
                } else if (elm.attr("class") == "dotted") {
                    return;
                }
                elm.addEv("click", () => {
                    let offset = elm.attr("data-offset");
                    _.fetch_my_apl(offset);
                });
            });
        }
    };
    BB.fetch_apl = function(offset = 0) {
        let bld_group = _.gid("blood_group").value,
            district = _.gid("district").value,
            total_apps = _.qs(".total_apps"),
            bld_nm = _.qs(".bld_nm"),
            cty_nm = _.qs(".cty_nm");
        if (bld_group == "রক্তের গ্রুপ") {
            bld_group = "";
        }
        bld_group = encodeURIComponent(bld_group);
        if (district == "জেলা") {
            district = "";
        }
        district = encodeURIComponent(district);
        _.cursor_wait();
        _.show_loader();
        client.post({
            url: "/api/fetch-apl",
            data: {
                blood_group: bld_group,
                district: district,
                offset: offset,
            },
            headers: _.bh_cui(),
            success: function(data, status, XHR) {
                try {
                    let JD = JSON.parse(data);
                    if (!JD) {
                        showMessage.show("Unknown data returned.");
                        return;
                    } else if (JD.status == "error") {
                        showMessage.show(JD.message);
                        return;
                    }
                    let content = JD.content,
                        pagination = JD.pagination,
                        total = JD.total;
                    bld_group = JD.blood_group;
                    district = JD.district;
                    total_apps.text(`${total}টি`);
                    if (bld_group !== undefined) {
                        if (bld_group) {
                            bld_nm.text(`${bld_group} রক্তের`);
                        } else {
                            bld_nm.text("");
                        }
                    }
                    district && cty_nm.text(`"${district}" জেলায়`);
                    _.qs(".post_wrapper").html(content);
                    _.qs(".pagination").html(pagination);
                    _.report_btn_handler();
                    _.pagination_bh();
                } catch (error) {}
            },
            error: function(XHR, status, message) {
                _.app_mode(status, XHR);
                showMessage.show(message);
            },
            complete: function(XHR, message) {
                _.hide_loader();
                _.cursor_default();
            },
        });
    };
    BB.fetch_my_apl = function(offset = 0) {
        let page = BB_glo_data.page;
        _.cursor_wait();
        _.show_loader();
        client.post({
            url: "/api/fetch-my-apl",
            data: {
                offset: offset,
            },
            headers: _.bh_cui(),
            success: function(data, status, XHR) {
                try {
                    let JD = JSON.parse(data);
                    if (!JD) {
                        showMessage.show("Unknown data returned.");
                        return;
                    } else if (JD.status == "error") {
                        showMessage.show(JD.message);
                        return;
                    }
                    let content = JD.content,
                        pagination = JD.pagination,
                        total_apps = JD.total;
                    if (total_apps) {
                        _.qs(".post_wrapper").html(content);
                    } else {
                        let post = "কোন আবেদন পাওয়া যায় নি.";
                        _.qs(".post_wrapper").html(post);
                    }
                    _.qs(".pagination").html(pagination);
                    _.report_btn_handler(page);
                    _.pagination_bh();
                } catch (error) {}
            },
            error: function(XHR, status, message) {
                _.app_mode(status, XHR);
                showMessage.show(message);
            },
            complete: function(XHR, message) {
                _.hide_loader();
                _.cursor_default();
            },
        });
    };
    BB.homeRnd = function() {
        let data = BB_glo_data,
            u_city = data.ip_city,
            page = data.page;
        if (page == "home") {
            if (_.ls_has("u_city")) {
                u_city = _.ls_get("u_city");
            }
            let xpath = "//option[contains(text(), '" + u_city + "')]",
                ele_match = _.findXPath(xpath),
                district = _.gid("district"),
                districts = _.qsa(".district ._option"),
                bld_groups = _.qsa(".blood_group ._option");
            ele_match && _w.dropdown.update(district, ele_match);
            _.init_cb(function() {
                _.fetch_apl();
            });
            districts.forEach(function(elm) {
                elm.addEv("click", function() {
                    u_city = this.innerText.trim();
                    if (u_city != "সব জেলা") {
                        _.ls_set("u_city", u_city);
                    }
                    _.fetch_apl();
                });
            });
            bld_groups.forEach(function(elm) {
                elm.addEv("click", function() {
                    _.fetch_apl();
                });
            });
        } else if (page == "my-apps") {
            _.init_cb(function() {
                _.fetch_my_apl();
            });
        }
    };
    BB.init_cb = function(callback) {
        let interval_di = setInterval(() => {
            if (!_.initialized) return;
            clearInterval(interval_di);
            callback();
        }, 200);
    };
    BB.tracker_updater = function(data) {
        const phone_hc = _.qs(".phone .hit_counter");
        const telegram_hc = _.qs(".telegram .hit_counter");
        const messenger_hc = _.qs(".messenger .hit_counter");
        const whatsapp_hc = _.qs(".whatsapp .hit_counter");
        try {
            let JD = JSON.parse(data);
            if (!JD || JD.status == "error") return;
            let total_pn = JD.pn,
                total_tg = JD.tg,
                total_mg = JD.mg,
                total_wa = JD.wa;
            total_pn && phone_hc.text(total_pn);
            total_tg && telegram_hc.text(total_tg);
            total_mg && messenger_hc.text(total_mg);
            total_wa && whatsapp_hc.text(total_wa);
        } catch (error) {}
    };
    BB.btn_tracker = function() {
        const phone_btn = _.qs("a.phone");
        const telegram_btn = _.qs("a.telegram");
        const messenger_btn = _.qs("a.messenger");
        const whatsapp_btn = _.qs("a.whatsapp");
        phone_btn && phone_btn.addEv("click", function() {
            _.init_cb(function() {
                client.post({
                    url: "/api/tracker",
                    data: {
                        form_id: form_id,
                        method: "phone",
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        _.tracker_updater(data);
                    },
                });
            });
        });
        telegram_btn && telegram_btn.addEv("click", function() {
            _.init_cb(function() {
                client.post({
                    url: "/api/tracker",
                    data: {
                        form_id: form_id,
                        method: "telegram",
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        _.tracker_updater(data);
                    },
                });
            });
        });
        messenger_btn && messenger_btn.addEv("click", function() {
            _.init_cb(function() {
                client.post({
                    url: "/api/tracker",
                    data: {
                        form_id: form_id,
                        method: "messenger",
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        _.tracker_updater(data);
                    },
                });
            });
        });
        whatsapp_btn && whatsapp_btn.addEv("click", function() {
            _.init_cb(function() {
                client.post({
                    url: "/api/tracker",
                    data: {
                        form_id: form_id,
                        method: "whatsapp",
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        _.tracker_updater(data);
                    },
                });
            });
        });
    };
    BB.report_handler = function() {
        const report = _.qs(".report");
        const report_btn = _.qs(".report_button");
        const total_report = _.qs(".total_report ._num");
        let total_num = parseInt(total_report.innerText);
        if (!report_btn) return;

        function rep_btn_pe(_clickable = true) {
            if (_clickable) {
                report_btn.style.cursor = "pointer";
                report_btn.style.pointerEvents = "auto";
            } else {
                report_btn.style.cursor = "default";
                report_btn.style.pointerEvents = "none";
            }
        }
        report_btn.addEv("click", function() {
            _.init_cb(function() {
                _.cursor_wait();
                _.show_inline_loader();
                rep_btn_pe(false);
                client.post({
                    url: "/api/report",
                    data: {
                        apl_id: form_id,
                    },
                    headers: _.bh_cui(),
                    success: function(data, status, XHR) {
                        try {
                            let JD = JSON.parse(data);
                            if (!JD) return;
                            if (JD.status == "error") {
                                showMessage.show(JD.message);
                                return;
                            }
                            report && report.remove();
                            if (JD.total && total_report) {
                                total_report.text(JD.total);
                            }
                            if (JD.reload) {
                                _w.location.reload();
                            }
                        } catch (error) {}
                    },
                    error: function(XHR, status, message) {
                        _.app_mode(status, XHR);
                        showMessage.show(message);
                    },
                    complete: function(XHR, message) {
                        rep_btn_pe();
                        _.hide_inline_loader();
                        _.cursor_default();
                    },
                });
            });
        });
    };
    BB.render_rep_btn = function() {
        _.show_loader();
        client.post({
            url: "/api/render-rep",
            data: {
                apl_id: form_id,
            },
            headers: _.bh_cui(),
            success: function(data, status, XHR) {
                try {
                    let JD = JSON.parse(data);
                    if (!JD || JD.status == "error") {
                        return;
                    }
                    let content = JD.content;
                    if (content) {
                        _.qs(".report_btn_sec").insertHTML(content);
                        _.report_handler();
                    }
                } catch (error) {}
            },
            complete: function(XHR, message) {
                _.hide_loader();
            },
        });
    };
    BB.detail_init = function() {
        _.init_cb(function() {
            let sTag = _d.createElement("script");
            sTag.src = "/static/js/ua-parser.min.js";
            _d.body.appendChild(sTag);
            sTag.onload = function() {
                _.render_rep_btn();
                let parser = new UAParser(navigator.userAgent),
                    result = parser.getResult(),
                    browser = result.browser ? result.browser.name : "",
                    version = result.browser ? result.browser.version : "",
                    os = result.os ? result.os.name : "";
                client.post({
                    url: "/api/visitor",
                    data: {
                        form_id: form_id,
                        browser: browser,
                        version: version,
                        os: os,
                        ua: _w.navigator.userAgent,
                    },
                    headers: _.bh_cui(),
                });
            };
        });
        _.btn_tracker();
        let share = _.qs("p.share"),
            data = BB_glo_data,
            hospital = data.hospital,
            district = data.district,
            app_url = data.app_url,
            bag = data.bag,
            group = data.group,
            donation_date = data.donation_date,
            patient_cond = data.patient_cond,
            share_text = `${hospital}, ${district} এ ${bag} ব্যাগ ${group} রক্তের প্রয়োজন।\n• রক্ত প্রয়োজনের সময়: ${donation_date}\n• রোগীর সমস্যা: ${patient_cond}\n\n• বিস্তারিত: `;
        share.addEv("click", () => {
            shareIt.share({
                title: _d.title,
                description: share_text,
                url: app_url,
            }, () => _w.showMessage.show("তথ্য কপি হয়েছে"));
        });
    };
    BB.initialized = !1;
    BB.init = function() {
        const user_id = _.qs('meta[name="user_id"]');
        if (!_.ls_has("user_id")) {
            let fp_js = _.gid("fp_js");
            fp_js.src = "//openfpcdn.io/fingerprintjs/v3/iife.min.js";
            fp_js.onload = function() {
                const fpPromise = FingerprintJS.load();
                fpPromise.then((fp) => fp.get()).then((result) => {
                    user_id.content = result.visitorId;
                    _.ls_set("user_id", result.visitorId);
                    _.initialized = !0;
                });
            };
        } else {
            user_id.content = _.ls_get("user_id");
            _.initialized = !0;
        }
    };
    BB.app_mode = function(status, XHR) {
        if (status == 503) {
            let headers = XHR.headers;
            if (headers.x_app_mode == "maintenance") {
                _w.location.reload();
            }
        }
    };
    _w._ = _w.BB = BB;
    elm.prototype.qs = _.qs;
    elm.prototype.qsa = _.qsa;
    elm.prototype.attr = _.attr;
    elm.prototype.html = _.html;
    elm.prototype.insertHTML = _.insertHTML;
    elm.prototype.text = _.text;
    elm.prototype.addEv = _.addEv;
    elm.prototype.delEv = _.delEv;
    String.prototype.lc = _.lowercase;
    String.prototype.uc = _.uppercase;
    String.prototype.str = _.str;
    String.prototype.ltrim = _.ltrim;
    String.prototype.rtrim = _.rtrim;
    _w.addEv = _.addEv;
    _.init();
})(window, document);
(function(_w) {
    var client = client || {};
    client.data = null;
    client.async = true;
    client.cache = false;
    client.contentType = "";
    client.headers = {};
    client.get = function(url, options) {
        if (typeof url === "object") {
            options = url;
            url = options.url;
        } else {
            options = options || {};
            options.url = url;
        }
        options.method = "get";
        this.exec(options);
    };
    client.post = function(url, options) {
        if (typeof url === "object") {
            options = url;
            url = options.url;
        } else {
            options = options || {};
            options.url = url;
        }
        options.method = "post";
        this.exec(options);
    };
    client.exec = function(options) {
        const contentType = "application/x-www-form-urlencoded";
        options = options || {};
        options.url = options.url || "";
        options.method = options.method || "GET";
        options.async = options.async || true;
        options.cache = options.cache || false;
        options.data = options.data || null;
        options.headers = options.headers || {};
        options.dataType = options.dataType || "";
        options.beforeSend = this.fnc(options, "beforeSend");
        options.complete = this.fnc(options, "complete");
        options.error = this.fnc(options, "error");
        options.success = this.fnc(options, "success");
        let req_method = options.method.uc();
        if (req_method == "GET" && options.data) {
            let query = options.data,
                url_q = "";
            options.data = null;
            if (query instanceof Array) {
                for (let index = 0; index < query.length; index++) {
                    const param = query[index];
                    url_q += "&" + param + "=";
                }
            } else if (query instanceof Object) {
                let key;
                for (key in query) {
                    const value = query[key];
                    url_q += "&" + key + "=" + value;
                }
            } else if (typeof query === "string") {
                url_q += query;
            }
            if (options.url.indexOf("?") !== -1) {
                options.url += url_q;
            } else {
                options.url += "?" + url_q.substring(1);
            }
        }
        let formData = {
            url: options.url,
            method: options.method,
            async: options.async,
            cache: options.cache,
            data: options.data,
            headers: options.headers,
            contentType: options.contentType,
            beforeSend: function(XHR, settings) {
                options.beforeSend(XHR, settings);
            },
            complete: function(XHR, textStatus) {
                options.complete(XHR, textStatus);
            },
            error: function(XHR, textStatus, errorThrown) {
                options.error(XHR, textStatus, errorThrown);
            },
            success: function(data, textStatus, XHR) {
                options.success(data, textStatus, XHR);
            },
        };
        if (req_method == "POST") {
            formData.contentType = options.contentType || contentType;
            let req_body = options.data,
                fct = formData.contentType;
            if (typeof req_body === "object" && !Array.isArray(req_body)) {
                if (/x\-www\-form/.test(fct)) {
                    let form_data = [];
                    for (var key in req_body) {
                        var value = req_body[key];
                        form_data.push(key + "=" + value);
                    }
                    formData.data = form_data.join("&");
                } else if (/\/json/.test(fct)) {
                    formData.data = JSON.stringify(req_body);
                }
            } else if (Array.isArray(req_body)) {
                if (/x\-www\-form/.test(fct)) {
                    formData.data = req_body.join("&");
                } else if (/\/json/.test(fct)) {
                    formData.data = JSON.stringify(req_body);
                }
            }
        }
        if (options.dataType) {
            formData.dataType = options.dataType;
        }
        this.ajax(formData);
    };
    client.fnc = function(object, fnc) {
        if (typeof object[fnc] === "function") {
            return object[fnc];
        }
        return function() {};
    };
    client.setHeaders = function(xhr, headers = {}) {
        let index;
        for (index in headers) {
            const val = headers[index];
            xhr.setRequestHeader(index, val);
        }
    };
    client.getHeaders = function(xhr) {
        const headerMap = {};
        if (xhr.readyState === 4) {
            const contentType = xhr.getResponseHeader("Content-Type");
            if (contentType !== "text/html") {}
            const headers = xhr.getAllResponseHeaders();
            const arr = headers.trim().split(/[\r\n]+/);
            arr.forEach((line) => {
                const parts = line.split(": ");
                const header = parts.shift();
                const value = parts.join(": ");
                headerMap[header] = value;
            });
        }
        return headerMap;
    };
    client.ajax = function(options) {
        let url = options.url,
            method = options.method,
            async = options.async,
            data = options.data,
            beforeSend = options.beforeSend,
            complete = options.complete,
            error = options.error,
            success = options.success,
            timeout = options.timeout || 30 * 1000,
            withCredentials = options.withCredentials || false,
            xhr = new XMLHttpRequest();
        if (options.mimeType) {
            xhr.overrideMimeType(options.mimeType);
        }
        xhr.withCredentials = withCredentials;
        xhr.timeout = timeout;
        xhr.onloadstart = function() {
            if (typeof beforeSend === "function") {
                beforeSend(this);
            }
        };
        xhr.onprogress = function() {};
        xhr.onreadystatechange = function() {
            if (this.readyState === 4) {
                this.headers = client.getHeaders(this);
                if (this.status >= 200 && this.status < 300) {
                    if (typeof success === "function") {
                        const returnURL = this.responseURL;
                        success(this.responseText, this.statusText, this);
                    }
                } else {
                    if (typeof error === "function") {
                        error(this, this.status, this.statusText);
                    }
                }
            }
        };
        xhr.onload = function() {};
        xhr.onloadend = function(e) {
            if (typeof complete === "function") {
                complete(this, this.statusText);
            }
        };
        if (method == "get") {
            xhr.open("GET", url, async);
            this.setHeaders(xhr, options.headers);
            xhr.send();
        } else {
            xhr.open("POST", url, async);
            this.setHeaders(xhr, options.headers);
            xhr.setRequestHeader("Content-Type", options.contentType);
            xhr.send(data);
        }
        xhr.ontimeout = function(e) {
            if (typeof error === "function") {
                error(this, this.status, this.statusText);
            }
        };
        xhr.onerror = function(ev) {
            let statusText = this.statusText;
            if (this.status == 0 && statusText == "") {
                statusText = "No Internet Connection.";
            }
            error(this, this.status, statusText);
        };
        xhr.onabort = function() {
            error(this, this.status, "aborted");
        };
    };
    _w.client = client;
})(window);
(function(_w) {
    var net_conn = window.net_conn || {};
    net_conn.isrunning = !1;
    net_conn.continue = !0;
    net_conn.ajax_loaded = !0;
    net_conn.net_stat = "online";
    net_conn.status_url = "/api/status";
    net_conn.offline_time = 0;
    net_conn.stop_timer = !1;
    net_conn.offline_timer = function() {
        let ot_interval = setInterval(() => {
            if (net_conn.net_stat == "offline") {
                net_conn.offline_time++;
            } else if (net_conn.offline_time) {
                net_conn.offline_time = 0;
            }
            if (net_conn.offline_time > 1000 * 540) {
                clearInterval(ot_interval);
                window.location.reload();
            } else if (net_conn.stop_timer) {
                clearInterval(ot_interval);
            }
        }, 1000);
    };
    net_conn.check = function() {
        client.get({
            url: net_conn.status_url,
            data: {
                rqn: new Date().getTime(),
            },
            success: function(data, status, XHR) {
                if (net_conn.net_stat != "online") {
                    net_conn.net_stat = "online";
                }
            },
            error: function(XHR, status, message) {
                if (net_conn.net_stat != "offline") {
                    net_conn.net_stat = "offline";
                }
                _.app_mode(status, XHR);
            },
            complete: function(XHR, message) {
                net_conn.ajax_loaded = !0;
            },
        });
    };
    net_conn.run = function(check_interval = 15000) {
        let interval_net = setInterval(() => {
            if (!this.continue) {
                clearInterval(interval_net);
                return;
            }
            if (!this.ajax_loaded) {
                return;
            } else {
                this.ajax_loaded = !1;
            }
            this.check();
        }, check_interval);
        this.offline_timer();
    };
    net_conn.stop = function() {
        this.continue = !1;
        this.stop_timer = !0;
    };
    _w.net_conn = net_conn;
})(window);
(function(_w, _d) {
    const refreshThreshold = 300;
    let startY;
    let isRefreshing = false;
    _d.addEventListener("touchstart", handleTouchStart);
    _d.addEventListener("touchmove", handleTouchMove);
    _d.addEventListener("touchend", handleTouchEnd);

    function handleTouchStart(event) {
        if (isRefreshing) return;
        startY = event.touches[0].clientY;
    }

    function handleTouchMove(event) {
        if (isRefreshing) return;
        const currentY = event.touches[0].clientY;
        const distance = currentY - startY;
        if (distance > refreshThreshold) {
            event.preventDefault();
        }
    }

    function handleTouchEnd(event) {
        if (isRefreshing) return;
        const currentY = event.changedTouches[0].clientY;
        const distance = currentY - startY;
        if (distance > refreshThreshold) {
            refreshContent();
        }
    }

    function refreshContent() {
        isRefreshing = true;
        _w.location.reload();
        setTimeout(() => {
            isRefreshing = false;
        }, 2000);
    }
})(window, document);
window.addEventListener("DOMContentLoaded", () => {
    let t = document.querySelectorAll("input[type=text], textarea");
    ((t && t instanceof window.NodeList) || Array.isArray(t)) && t.forEach((t) => {
        t ? .nextElementSibling ? .classList.contains("optional_text") && (t.style.paddingRight = "45px");
    });
});